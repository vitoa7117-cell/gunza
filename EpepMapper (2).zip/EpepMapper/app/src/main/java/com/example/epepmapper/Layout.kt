package com.example.epepmapper

import android.view.KeyEvent

const val FIRE = -1   // klik kiri mouse
const val SCOPE = -2  // klik kanan mouse
const val JOY = -10   // jari virtual untuk joystick
const val CAM = -11   // jari virtual untuk kamera

// id -> (label, x awal, y awal). Posisi = pecahan layar landscape.
// Ini hanya nilai awal; tiap game punya posisi sendiri yang diatur lewat tombol roda gigi di dalam game.
object Layout {
    const val JOY_RADIUS = 0.10f // pecahan tinggi layar

    val items = linkedMapOf(
        JOY to Triple("Gerak\nWASD", 0.18f, 0.75f),
        CAM to Triple("Kamera\nmouse", 0.66f, 0.45f),
        FIRE to Triple("Tembak\nKlik L", 0.82f, 0.70f),
        SCOPE to Triple("Scope\nKlik R", 0.75f, 0.60f),
        KeyEvent.KEYCODE_SPACE to Triple("Lompat\nSpasi", 0.92f, 0.68f),
        KeyEvent.KEYCODE_R to Triple("Reload\nR", 0.81f, 0.13f),
        KeyEvent.KEYCODE_C to Triple("Jongkok\nC", 0.91f, 0.85f),
        KeyEvent.KEYCODE_Z to Triple("Tiarap\nZ", 0.85f, 0.90f),
        KeyEvent.KEYCODE_F to Triple("Aksi\nF", 0.38f, 0.62f),
    )
}
