package com.example.epepmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

private const val TICK = 40L // ms per potongan gestur
private val MOVE = setOf(KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D)

class MapperService : AccessibilityService() {
    private class Finger(var stroke: GestureDescription.StrokeDescription? = null, var cur: PointF = PointF())

    private val fingers = HashMap<Int, Finger>()
    private val pressed = HashSet<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private var dx = 0f
    private var dy = 0f
    private var lastX = Float.NaN
    private var lastY = Float.NaN
    private var running = false

    private var pkg: String? = null   // aplikasi yang sedang di depan
    private var on = false            // true kalau aplikasi di depan ada di daftar game
    private var pos: Map<Int, PointF> = emptyMap()
    private var editor: View? = null
    private var gear: View? = null
    private val wm: WindowManager get() = getSystemService(WindowManager::class.java)

    override fun onServiceConnected() {
        instance = this
        pos = Store.load(this, "")
        serviceInfo = serviceInfo.apply {
            if (Build.VERSION.SDK_INT >= 34) motionEventSources = InputDevice.SOURCE_MOUSE
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        editor?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        editor = null
        hideGear()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || editor != null) return
        val p = e.packageName?.toString() ?: return
        // abaikan jendela sistem dan jendela milik kita sendiri
        if (p == packageName || p == "android" || "systemui" in p || "inputmethod" in p || "securitycenter" in p) return
        if (p != pkg) { pressed.clear(); start() }
        pkg = p
        on = p in Store.games(this)
        if (on) { pos = Store.load(this, p); showGear() } else hideGear()
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (!on || editor != null) return false
        val k = e.keyCode
        if (k !in Layout.items && k !in MOVE) return false // tombol lain lewat seperti biasa
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(k) else if (e.action == KeyEvent.ACTION_UP) pressed.remove(k)
        start()
        return true
    }

    // Hanya dipanggil di Android 14+ (API 34)
    override fun onMotionEvent(event: MotionEvent) {
        if (!on || editor != null) return
        if ((event.source and InputDevice.SOURCE_MOUSE) != InputDevice.SOURCE_MOUSE) return
        when (event.actionMasked) {
            MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_MOVE -> {
                if (!lastX.isNaN()) { dx += event.x - lastX; dy += event.y - lastY }
                lastX = event.x; lastY = event.y
            }
            MotionEvent.ACTION_BUTTON_PRESS -> button(event, true)
            MotionEvent.ACTION_BUTTON_RELEASE -> button(event, false)
        }
        start()
    }

    private fun button(e: MotionEvent, down: Boolean) {
        val c = if (e.actionButton == MotionEvent.BUTTON_SECONDARY) SCOPE else FIRE
        if (down) pressed.add(c) else pressed.remove(c)
    }

    private fun start() { if (!running) { running = true; tick() } }

    // Satu gestur = semua jari sekaligus, karena dispatchGesture membatalkan gestur lain yang sedang jalan.
    private fun tick() {
        val b = wm.currentWindowMetrics.bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        fun px(id: Int): PointF { val q = pos[id]!!; return PointF(q.x * w, q.y * h) }

        val want = HashMap<Int, PointF>() // posisi tujuan jari; tidak ada = jari diangkat
        val home = HashMap<Int, PointF>() // posisi awal jari baru
        for (k in pressed) if (k in pos) { want[k] = px(k); home[k] = px(k) }

        val c = px(JOY)
        home[JOY] = c
        val ax = (if (KeyEvent.KEYCODE_D in pressed) 1 else 0) - (if (KeyEvent.KEYCODE_A in pressed) 1 else 0)
        val ay = (if (KeyEvent.KEYCODE_S in pressed) 1 else 0) - (if (KeyEvent.KEYCODE_W in pressed) 1 else 0)
        if (ax != 0 || ay != 0) {
            val l = hypot(ax.toFloat(), ay.toFloat())
            val r = Layout.JOY_RADIUS * h
            want[JOY] = PointF(c.x + ax / l * r, c.y + ay / l * r)
        }

        val sens = Store.sens(this)
        val mx = dx * sens
        val my = dy * sens
        dx = 0f; dy = 0f
        val camHome = px(CAM)
        home[CAM] = camHome
        if (mx != 0f || my != 0f) {
            val from = fingers[CAM]?.takeIf { it.stroke != null }?.cur ?: camHome
            val tx = from.x + mx
            val ty = from.y + my
            // keluar layar -> jari diangkat, geseran berikutnya mulai lagi dari titik awal
            if (tx in 0f..w && ty in 0f..h) want[CAM] = PointF(tx, ty)
        }

        val g = GestureDescription.Builder()
        var n = 0
        for (id in (fingers.keys + want.keys).toSet()) {
            val f = fingers.getOrPut(id) { Finger() }
            val t = want[id]
            if (t == null && f.stroke == null) { fingers.remove(id); continue }
            val from = if (f.stroke == null) home[id]!! else f.cur
            val to = t ?: from
            val p = Path().apply {
                moveTo(from.x, from.y)
                if (to.x != from.x || to.y != from.y) lineTo(to.x, to.y)
            }
            val s = f.stroke?.continueStroke(p, 0, TICK, t != null)
                ?: GestureDescription.StrokeDescription(p, 0, TICK, t != null)
            f.stroke = if (t != null) s else null
            f.cur = to
            g.addStroke(s)
            n++
        }
        if (n == 0) { running = false; return }

        val ok = dispatchGesture(g.build(), object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { tick() }
            override fun onCancelled(d: GestureDescription?) { fingers.clear(); handler.postDelayed({ tick() }, 50) }
        }, null)
        if (!ok) { fingers.clear(); running = false }
    }

    // Tombol roda gigi melayang yang bisa digeser; ketuk untuk membuka editor.
    private fun showGear() {
        if (gear != null) return
        val b = wm.currentWindowMetrics.bounds
        val size = (b.height() * 0.09f).toInt()
        val v = TextView(this)
        v.text = "⚙"; v.textSize = 20f; v.gravity = Gravity.CENTER; v.setTextColor(Color.WHITE)
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x88000000.toInt()) }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (b.width() * 0.34f).toInt(); lp.y = 0
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = (e.rawX - sx).toInt()
                    val ddy = (e.rawY - sy).toInt()
                    if (abs(ddx) + abs(ddy) > 16) moved = true
                    lp.x = ox + ddx; lp.y = oy + ddy
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) openEditor()
            }
            true
        }
        wm.addView(v, lp)
        gear = v
    }

    private fun hideGear() {
        gear?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        gear = null
    }

    // Editor: lingkaran yang digeser ke atas tombol asli di layar game, lalu Simpan.
    private fun openEditor() {
        val g = pkg ?: return
        if (editor != null) return
        hideGear(); pressed.clear(); start()
        val b = wm.currentWindowMetrics.bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val dp = resources.displayMetrics.density
        val cur = HashMap(pos)

        val root = FrameLayout(this)
        root.setBackgroundColor(0x77000000)
        for ((id, item) in Layout.items) {
            val size = (if (id == JOY) 2 * Layout.JOY_RADIUS * h else h * 0.12f).toInt()
            val v = TextView(this)
            v.text = item.first; v.gravity = Gravity.CENTER; v.textSize = 10f; v.setTextColor(Color.WHITE)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x992457FF.toInt())
                setStroke((2 * dp).toInt(), Color.WHITE)
            }
            root.addView(v, FrameLayout.LayoutParams(size, size))
            fun place() { v.x = cur[id]!!.x * w - size / 2f; v.y = cur[id]!!.y * h - size / 2f }
            place()
            v.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                    cur[id] = PointF((e.rawX / w).coerceIn(0f, 1f), (e.rawY / h).coerceIn(0f, 1f))
                    place()
                }
                true
            }
        }

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xCC000000.toInt())
        bar.setPadding((12 * dp).toInt(), (4 * dp).toInt(), (12 * dp).toInt(), (4 * dp).toInt())
        val hint = TextView(this)
        hint.text = "Geser lingkaran ke tombol game  "; hint.setTextColor(Color.WHITE)
        val save = Button(this)
        save.text = "Simpan"
        save.setOnClickListener { Store.save(this, g, cur); pos = cur; closeEditor() }
        val cancel = Button(this)
        cancel.text = "Batal"
        cancel.setOnClickListener { closeEditor() }
        bar.addView(hint); bar.addView(save); bar.addView(cancel)
        root.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
        )

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(root, lp)
        editor = root
    }

    private fun closeEditor() {
        editor?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        editor = null
        if (on) showGear()
    }

    companion object {
        @JvmStatic var instance: MapperService? = null
    }
}
