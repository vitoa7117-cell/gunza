package com.example.epepmapper

import android.content.Context
import android.graphics.PointF
import org.json.JSONArray
import org.json.JSONObject

// Daftar game dan posisi tombol per game, disimpan di SharedPreferences.
object Store {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun games(c: Context): List<String> = p(c).getStringSet("games", emptySet())!!.toList()

    fun add(c: Context, pkg: String) {
        val s = HashSet(p(c).getStringSet("games", emptySet())!!)
        s.add(pkg)
        p(c).edit().putStringSet("games", s).apply()
    }

    fun remove(c: Context, pkg: String) {
        val s = HashSet(p(c).getStringSet("games", emptySet())!!)
        s.remove(pkg)
        p(c).edit().putStringSet("games", s).remove("pos_$pkg").apply()
    }

    fun sens(c: Context): Float = p(c).getInt("sens", 30) / 10f

    // Posisi awal dari Layout, ditimpa posisi tersimpan milik game ini.
    fun load(c: Context, pkg: String): Map<Int, PointF> {
        val m = HashMap<Int, PointF>()
        for ((k, v) in Layout.items) m[k] = PointF(v.second, v.third)
        try {
            val j = JSONObject(p(c).getString("pos_$pkg", "{}")!!)
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                m[k.toInt()] = PointF(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
            }
        } catch (e: Exception) {
        }
        return m
    }

    fun save(c: Context, pkg: String, m: Map<Int, PointF>) {
        val j = JSONObject()
        for ((k, v) in m) j.put(k.toString(), JSONArray(listOf(v.x.toDouble(), v.y.toDouble())))
        p(c).edit().putString("pos_$pkg", j.toString()).apply()
    }
}
