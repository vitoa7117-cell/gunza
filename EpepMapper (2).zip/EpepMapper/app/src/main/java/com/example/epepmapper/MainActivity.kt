package com.example.epepmapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(48, 48, 48, 48)

        status = TextView(this)
        col.addView(status)

        val acc = Button(this)
        acc.text = "Buka pengaturan aksesibilitas"
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(acc)

        val head = TextView(this)
        head.text = "\nGame saya"
        head.textSize = 18f
        col.addView(head)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)

        val add = Button(this)
        add.text = "+ Tambah game"
        add.setOnClickListener { pick() }
        col.addView(add)

        val sensLabel = TextView(this)
        sensLabel.text = "\nSensitivitas mouse"
        col.addView(sensLabel)
        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = prefs.getInt("sens", 30)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { prefs.edit().putInt("sens", p).apply() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar)

        val how = TextView(this)
        how.text = "\nCara atur tombol:\n" +
            "1. Aktifkan Epep Mapper di Aksesibilitas.\n" +
            "2. Tambah game, lalu ketuk namanya untuk membukanya.\n" +
            "3. Di dalam game (saat HUD terlihat) ketuk tombol ⚙ melayang di atas layar. Tombol ini bisa digeser.\n" +
            "4. Geser tiap lingkaran ke atas tombol aslinya, lalu Simpan.\n" +
            "Tombol keyboard dan mouse hanya aktif di game yang ada di daftar."
        col.addView(how)

        val root = ScrollView(this)
        root.addView(col)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        var kb = false
        var ms = false
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) ms = true
            if (d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) kb = true
        }
        val on = MapperService.instance != null
        status.text = "Aksesibilitas: " + (if (on) "AKTIF" else "NONAKTIF") +
            "\nKeyboard: " + (if (kb) "terdeteksi" else "tidak ada") +
            "\nMouse: " + (if (ms) "terdeteksi" else "tidak ada")

        list.removeAllViews()
        val pm = packageManager
        val games = Store.games(this)
        if (games.isEmpty()) {
            val t = TextView(this)
            t.text = "Belum ada game. Tekan + Tambah game."
            list.addView(t)
        }
        for (pkg in games) {
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val open = Button(this)
            open.text = "Buka: $label"
            open.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            open.setOnClickListener { openGame(pkg) }
            val del = Button(this)
            del.text = "Hapus"
            del.setOnClickListener { Store.remove(this, pkg); refresh() }
            row.addView(open)
            row.addView(del)
            list.addView(row)
        }
    }

    private fun openGame(pkg: String) {
        if (MapperService.instance == null) {
            Toast.makeText(this, "Aktifkan Epep Mapper di Aksesibilitas dulu", Toast.LENGTH_LONG).show()
        }
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun pick() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this)
            .setTitle("Pilih game")
            .setItems(apps.map { it.second }.toTypedArray()) { _, which ->
                Store.add(this, apps[which].first)
                refresh()
            }
            .show()
    }
}
